package org.jbpm.workflow.core.node;

import org.jbpm.workflow.core.impl.ExtendedNodeImpl;

public class CatchLinkNode extends ExtendedNodeImpl {


	private static final long serialVersionUID = 201105121554L;

}
