package org.jbpm.bpmn2.objects;

/**
 * Test or test part status
 */
public enum Status {
    SUCCESS, FAIL
}
