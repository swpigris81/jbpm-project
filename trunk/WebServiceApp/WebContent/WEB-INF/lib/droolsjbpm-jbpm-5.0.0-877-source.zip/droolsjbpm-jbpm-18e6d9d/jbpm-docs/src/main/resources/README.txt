
The diagrams were made with the community version of SQL Power*Architect. 

The database schema's which the diagrams were reverse engineered from, 
were from a postgresql database that was generated with the jbpm-installer 
demo. 

Once the diagrams had been generated and prettied up, a PDF was generated. 

GIMP was then used to generate a PNG file from the PDF. 

The jbpm (core) diagram PNG file should go here: 
- src/main/docbook/en-US/images/Chapter-Persistence/jbpm_schema.png

The BAM (logging) diagram PNG file should go here: 
- src/main/docbook/en-US/images/Chapter-Persistence/bam_schema.png

The human task diagram PNG file should go here: 
- src/main/docbook/en-US/images/Chapter-HumanTasks/human_task_schema.png

