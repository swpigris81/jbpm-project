/**
 * Business Activity Monitoring (BAM) resources supporting activity events and activity logs.
 */
 package org.jbpm.process.audit;