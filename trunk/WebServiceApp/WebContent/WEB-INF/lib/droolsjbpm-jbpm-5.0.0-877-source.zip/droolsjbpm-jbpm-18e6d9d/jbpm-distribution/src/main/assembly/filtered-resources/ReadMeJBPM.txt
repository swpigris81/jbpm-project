Welcome to jBPM
===============

Read the reference manual
-------------------------

To see the reference_manual, just open:
  reference_manual/html_single/index.html


Sources
-------

The source jars are in the sources directory.

But to build from sources, pull the sources with git:
  https://github.com/droolsjbpm
and follow these instructions:
  https://github.com/droolsjbpm/droolsjbpm-build-bootstrap/blob/master/README.md
